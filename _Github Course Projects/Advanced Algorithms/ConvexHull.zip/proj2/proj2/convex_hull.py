from which_pyqt import PYQT_VER
if PYQT_VER == 'PYQT5':
	from PyQt5.QtCore import QLineF, QPointF, QObject
else:
	raise Exception('Unsupported Version of PyQt: {}'.format(PYQT_VER))



import time
import math
# Some global color constants that might be useful
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)

# Global variable that controls the speed of the recursion automation, in seconds
#
PAUSE = 0.25

#
# This is the class you have to complete.
#
class ConvexHullSolver(QObject):

# Class constructor
	def __init__( self):
		super().__init__()
		self.pause = False
		
# Some helper methods that make calls to the GUI, allowing us to send updates
# to be displayed.

	def showTangent(self, line, color):
		self.view.addLines(line,color)
		if self.pause:
			time.sleep(PAUSE)

	def eraseTangent(self, line):
		self.view.clearLines(line)

	def blinkTangent(self,line,color):
		self.showTangent(line,color)
		self.eraseTangent(line)

	def showHull(self, polygon, color):
		self.view.addLines(polygon,color)
		if self.pause:
			time.sleep(PAUSE)
		
	def eraseHull(self,polygon):
		self.view.clearLines(polygon)
		
	def showText(self,text):
		self.view.displayStatusText(text)
	

# This is the method that gets called by the GUI and actually executes
# the finding of the hull
	def compute_hull( self, points, pause, view):
		self.pause = pause
		self.view = view
		assert( type(points) == list and type(points[0]) == QPointF )

		t1 = time.time()
		# TODO: SORT THE POINTS BY INCREASING X-VALUE
		points.sort(key=QPointF.x)
		t2 = time.time()

		t3 = time.time()
		# this is a dummy polygon of the first 3 unsorted points
		#polygon = [QLineF(points[i],points[(i+1)%3]) for i in range(3)]
		# TODO: REPLACE THE LINE ABOVE WITH A CALL TO YOUR DIVIDE-AND-CONQUER CONVEX HULL SOLVER
		polyPoints = self.hullSolver(points, self.view)

		t4 = time.time()
		polygon2 = [QLineF(polyPoints[i], polyPoints[(i+1) % len(polyPoints)]) for i in range(len(polyPoints)) ]

		# when passing lines to the display, pass a list of QLineF objects.  Each QLineF
		# object can be created with two QPointF objects corresponding to the endpoints
		#self.showHull(polygon,RED)
		self.showHull(polygon2, BLUE)
		self.showText('Time Elapsed (Convex Hull): {:3.3f} sec'.format(t4-t3))


	def hullSolver(self, points, view):
		self.view = view
		self.points = points
		assert(type(points) == list and type(points[0] == QPointF))

		# Base case of 1 point.
		if(len(points) == 1):
			return points
		# line case
		elif(len(points) == 2):
			sortedPoints = sorted(points, key=QPointF.x)
			return sortedPoints

		else:
			# split list of points
			leftPoints = list()
			rightPoints = list()
			middle = math.floor(len(self.points)/2)
			for i in range(middle):
				leftPoints.append(self.points[i])
			while(middle < len(self.points)):
				rightPoints.append(self.points[middle])
				middle += 1

			leftPoints = self.hullSolver(leftPoints, self.view)
			rightPoints = self.hullSolver(rightPoints, self.view)

			# find the upper and lower tangents between left and right polygons
			UL = LL = sorted(leftPoints,key=QPointF.x)[-1]	# rightmost left poly point
			LR = UR = sorted(rightPoints,key=QPointF.x)[0]	# leftmost right poly point
			lowerTan = upperTan = False
			currLine = None
			while(not upperTan):
				while(True):
					currLine = QLineF(UL, UR)
					pointR = self.getNextPointClockwise(rightPoints, UR)
					newLine = QLineF(UL, pointR)
					if(newLine.dy()/newLine.dx() > currLine.dy()/currLine.dx()):
						currLine = newLine
						UR = pointR
					else:
						upperL = currLine
						break
				while(True):
					currLine = QLineF(UL, UR)
					pointL = self.getNextPointCounterClock(leftPoints, UL)
					newLine = QLineF(pointL, UR)
					if(newLine.dy()/newLine.dx() < currLine.dy()/currLine.dx()):
						currLine = newLine
						UL = pointL
					else:
						upperR = currLine
						break
				if(upperR == upperL): upperTan = True
				# TODO add condition change to break while loop, determine when upperTan is reached
			while(not lowerTan):
				while(True):
					currLine = QLineF(LL, LR)
					pointR = self.getNextPointCounterClock(rightPoints, LR)
					newLine = QLineF(LL, pointR)
					if(newLine.dy()/newLine.dx() < currLine.dy()/currLine.dx()):
						currLine = newLine
						LR = pointR
					else:
						lowerR = currLine
						break
				while(True):
					currLine = QLineF(LL, LR)
					pointL = self.getNextPointClockwise(leftPoints, LL)
					newLine = QLineF(pointL, LR)
					if(newLine.dy()/newLine.dx() > currLine.dy()/currLine.dx()):
						currLine = newLine
						LL = pointL
					else:
						lowerL = currLine
						break
				if(lowerL == lowerR): lowerTan = True
			# merge the list of points to form the new polygon
			poly = list()
			LLidx = leftPoints.index(LL)
			URidx = rightPoints.index(UR)
			for i in range(len(leftPoints)):
				point = leftPoints[(i+LLidx)%len(leftPoints)]
				if(point == UL):
					poly.append(point)
					break
				poly.append(point)
			for i in range(len(rightPoints)):
				point = rightPoints[(i+URidx)%len(rightPoints)]
				if(point == LR):
					poly.append(point)
					break
				poly.append(point)
			return poly



	# gets the next point in a list when moving clockwise, assumes a clockwise sorted list
	def getNextPointClockwise(self, points, currentPoint):
		self.points = points
		assert(type(points) == list and type(points[0]) == QPointF and type(currentPoint) == QPointF)
		index = points.index(currentPoint)
		if( index + 1  >= len(points)):
			return points[0]
		else:
			return points[index+1]

	# gets the next point in a list when moving counterclockwise, assumes a clockwise sorted list
	def getNextPointCounterClock(self, points, currentPoint):
		self.points = points
		assert (type(points) == list and type(points[0]) == QPointF and type(currentPoint) == QPointF)
		index = points.index(currentPoint)
		if(index == 0):
			return points[len(points) - 1]
		else:
			return points[index - 1]


	"""		Algorithm steps:
		Step 1: Sort points left to right based on X coordinate value
		Step 2: Split list of points in half until only the base case exists (**1 point**, 2 points, or 3 points)
		Step 3: Find the tangent(s) of the left and right polygons
			//Start with rightmost point of left hull and leftmost point of right hull
			RPolyPoint = rightPoints.Sorted(QPointF.x)[0] # i.e. the lowest x value point
			LPolyPoint = leftPoints.Sorted(QPointF.x)[-1] # i.e. the highest x value point
			line = QLineF(LPolyPoint, RPolyPoint)
			While(edge not upper tangent to both left and right):
				While(edge not upper tan to left):
					//move counter clockwise to next point on left hull
					// find line with greatest slope
					slope = (RPolyPoint.y - LPolyPoint.y)/(RPolyPoint.x - LPolyPoint.x)
				While(edge not upper tan to right):
					//move clockwise to next point on right hull
					// find line with least slope
			While(edge not lower tan to both left and right):
				While(edge not lower tan to left)
					//move clockwise to next point
					// find least slope
				While(edge not lower tan to right)
					//move counter clockwise to next point
					// find greatest slope
		Step 4: Connect the points into a polygon in clockwise order I.E. left poly: LL -> UL right poly: UR -> LR
			done = false
			for i = indexOf(LL), i < len(leftPoints), i++:
				if(leftPoints[i] == UL): add point to list, set done to True, and break
				else: add leftPoints[i] to list of points
			if(!done):
				for i = 0, i < indexOf(LL), i++:
					if(leftPoints[i] == UL): add point to list, set done to True, and break
					else: add leftPoints[i] to list of points
			done = false
			for i = indexOf(UR), i < len(rightPoints), i++:
				if(rightPoints[i] == LR): add point to list, set done to True, and break
				else: add rightPoints[i] to list of points
			if(!done):
				for i = 0, i < indexOf(UR), i++:
					if(rightPoints[i] == LR): add point to list, set done to True, and break
					else: add rightPoints[i] to list of points
		Step 5: Return the new ordered points of the polygon			
		
		Ex: A(1,5) B(2,5) C(2,7) D(4,6) E(6,8)
	"""