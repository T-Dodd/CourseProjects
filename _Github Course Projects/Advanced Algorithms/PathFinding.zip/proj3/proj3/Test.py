from NetworkRoutingSolver import ArrayQueue, HeapQueue
from CS4412Graph import *
# testing functionality of the PQueues
def main():
    size = 5
    keys = [2, 5, 1, 4, 3]
    print("ArrayQueue Test")
    AQ = ArrayQueue(size)
    for i in range(len(keys)):
        key = keys[i]
        AQ.insert(i + 1, key)
    node = AQ.deleteMin()
    print(f'Removing min key: node = {node}')
    print("Should be node 3\n")
    print("Decreasing key value of node 2 and remove it")
    AQ.decreaseKey(1, 2)
    node = AQ.deleteMin()
    print(f'Removed min, node = {node}')
    print("\n")

    print("HeapQueue Test")

if __name__ == '__main__':
    main()