#!/usr/bin/python3


from CS4412Graph import *
import time


class NetworkRoutingSolver:
    def __init__( self):
        pass

    def initializeNetwork( self, network ):
        assert( type(network) == CS4412Graph )
        self.network = network
    def getShortestPath( self, destIndex ):
        self.dest = destIndex
        # TODO: RETURN THE SHORTEST PATH FOR destIndex
        #       INSTEAD OF THE DUMMY SET OF EDGES BELOW
        #       IT'S JUST AN EXAMPLE OF THE FORMAT YOU'LL 
        #       NEED TO USE
        dist, prev = self.dist, self.prev
        path_edges = []
        total_length = 0
        node = self.network.nodes[self.dest]
        while True:
            if(prev[node.node_id] == None and node.node_id != self.source):
                return {'cost': float('inf'), 'path': path_edges}
            neighbors = self.network.nodes[prev[node.node_id]].neighbors
            for i in range(len(neighbors)):
                if neighbors[i].dest == node:
                    path_edges.append((neighbors[i].src.loc, node.loc, '{:.0f}'.format(neighbors[i].length)))
                    total_length += neighbors[i].length
                    newnode = self.network.nodes[prev[node.node_id]]
                    node = newnode
                    break
            if prev[node.node_id] == None:
                break
        return {'cost':total_length, 'path':path_edges}
    def computeShortestPaths( self, srcIndex, use_heap=False ):
        self.source = srcIndex
        t1 = time.time()

        if(use_heap):   # create PQueue with binary heap
            Q = HeapQueue(len(self.network.nodes), self.source)
            prev = [None] * len(self.network.nodes)
            dist = [float('inf')] * len(self.network.nodes)
            currentNode = self.network.nodes[self.source]
            dist[self.source] = 0
            '''while Q.size > 0:
                node_id = Q.deleteMin()
                node = self.network.nodes[node_id]
                for edge in node.neighbors:
                    dest = edge.dest
                    if (dist[dest.node_id] > (dist[node] + edge.length)):
                        dist[dest.node_id] = dist[node] + edge.length
                        prev[dest.node_id] = node
                        Q.decreaseKey(dist[node] + edge.length, edge.dest)'''
        else:           # create PQueue with Array
            Q = ArrayQueue(len(self.network.nodes), self.source)
            prev = [None] * len(self.network.nodes)
            dist = [float('inf')] * len(self.network.nodes)
            currentNode = self.network.nodes[self.source]
            dist[self.source] = 0

            while Q.size > 0:
                node_id = Q.deleteMin()
                node = self.network.nodes[node_id]
                for edge in node.neighbors:
                    dest = edge.dest
                    if(dist[dest.node_id] > (dist[node_id] + edge.length)):
                        dist[dest.node_id] = dist[node_id] + edge.length
                        prev[dest.node_id] = node_id
                        Q.decreaseKey(dist[node_id] + edge.length, edge.dest.node_id)
        self. dist = dist
        self.prev = prev

        # TODO: RUN DIJKSTRA'S TO DETERMINE SHORTEST PATHS.
        #       ALSO, STORE THE RESULTS FOR THE SUBSEQUENT
        #       CALL TO getShortestPath(dest_index)

        t2 = time.time()
        return (t2-t1)

# Priority queue implemented using array method
class ArrayQueue:
    def __init__(self, numNodes: int, start: int = 1):
        self.array = [float('inf')] * numNodes
        self.array[start] = 0
        self.size = numNodes

    # Removes the lowest priority element from the queue and returns its index -> node_id
    # if there are no more elements to remove, returns -1
    def deleteMin(self) -> int:
        min = None
        for i in range(len(self.array)):
            if(self.array[i] != None and (min == None or self.array[min] == None)):
                min = i
            elif(self.array[i] != None and self.array[min] != None and self.array[i] < self.array[min]):
                min = i
        if(min != None and type(min) == int):
            self.array[min] = None
            self.size -= 1
            return min
        else: return -1

    # Decrease the key value of the Node located in the PQueue
    def decreaseKey(self, newKey: int, node: int) -> None:
        self.array[node] = newKey

    def insert(self, node: int, key: int):
        if(node < len(self.array)):
            self.array[node] = key
        else: self.array.append(key)
        self.size += 1

# Priority queue implemented using binary heap method
class HeapQueue:
    # use 2n + 1 and 2n + 2 to get children nodes
    # parent = ceiling((child - 2) / 2)
    def __init__(self, numNodes: int, start: int):
        self.pointerArray = []
        self.bHeap = []
        self.size = numNodes
        self.insert(start, 0)


    def decreaseKey(self, node_id: int, key: int):
        pass
    def insert(self, node_id:int, key:int):
        # insert the node to bottom right-most entry

        pass
    def deleteMin(self):
        pass
    def bubbleUp(self):
        pass
    def bubbleDown(self):
        pass