import random

def prime_test(N, k):
	# This is main function, that is connected to the Test button. You don't need to touch it.
	return fermat(N,k), miller_rabin(N,k)


def mod_exp(x, y, N):
    # You will need to implement this function and change the return value.
    if(y == 0):                 # 1
        return 1                # 1
    z = mod_exp(x,int(y/2),N)   # y/2
    if(y%2 == 0):               # 1
        return (z*z)%N
    else:
        return (x*z*z)%N


def fprobability(k):
    # You will need to implement this function and change the return value.   
    return 1 - pow(0.5, k)


def mprobability(k):
    # You will need to implement this function and change the return value.   
    return 1 - pow(0.25, k)


def fermat(N,k):
    # You will need to implement this function and change the return value, which should be
    # either 'prime' or 'composite'.
	#
    # To generate random values for 'a', you will most likely want to use
    # random.randint(low,hi) which gives a random integer between low and
    #  hi, inclusive.

    for i in range(k):
        a = random.randint(1, N-1)
        test = mod_exp(a, N-1, N)
        if test != 1:
            return 'composite'
    else:
        return 'prime'


def miller_rabin(N,k):
    # You will need to implement this function and change the return value, which should be
    # either 'prime' or 'composite'.
	#
    # To generate random values for a, you will most likley want to use
    # random.randint(low,hi) which gives a random integer between low and
    #  hi, inclusive.
    for i in range(k):
        a = random.randint(1, N - 1)
        power = N - 1
        while (power > 0):
            test = mod_exp(a, power, N)
            if test == 1:
                power = int(power / 2)
                continue
            elif test == -1:
                return 'prime'
            else:
                return ' composite'
        return 'prime'