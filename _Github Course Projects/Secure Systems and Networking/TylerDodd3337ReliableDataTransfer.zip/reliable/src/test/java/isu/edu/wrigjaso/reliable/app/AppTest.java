package isu.edu.wrigjaso.reliable.app;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Test for simple case with no loss
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Tests for packet loss probability>0, packet corruption probability>0, and both>0
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
