package isu.edu.wrigjaso.reliable.app;
import java.util.ArrayList;

public class EntityB extends Entity {
	
	private byte checkSum;
	private ArrayList<Packet> packetsReceived;

	// Initialize anything you need here
	EntityB() {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
		this.packetsReceived = new ArrayList<Packet>();
		this.checkSum = 0x0;
	}

	// Called when layer5 wants to introduce new data into the stream
	// For EntityB, this function does not need to be filled in unless
	// you're doing the extra credit, bidirectional part of the assignment
	@Override
	void output(Message message) {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
	}
	
	// Called when the network has a packet for this entity
	@Override
	void input(Packet pkt) {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
		Packet response = new Packet();	//creating a packet object to be sent to Entity A with the response from B
		//check the packet for corruption using the checksum
		this.checkSum = 0x0;	//reinitialize the B side checksum to hex 0
		//adding each element in the payload to the B side checksum
		for(char c:pkt.payload)
		{
			byte b = (byte) c;	//getting the byte value of the current character in the payload
			this.checkSum += b;	//adding the byte value of the payload char to the B side checksum
		}
		this.checkSum += pkt.checksum;	//adding the packet checksum to the B side calculated checksum (should be 11111111...)
		//send NACK message to entity A to have packet resent (packet was corrupted)
		if(Byte.toString(this.checkSum).contains("0"))
		{
			response.payload = "NACK".toCharArray();
			response.acknum = pkt.acknum;
		}
		//send ACK message to entity A to confirm packet received
		else
		{
			response.payload = "ACK".toCharArray();
			response.acknum = pkt.acknum;
		}
		tolayer3(response);
		tolayer5(pkt.payload);

	}

	// called when your timer has expired (not needed since timer interrupt from A will occur if a response is not received)
	@Override
	void timerinterrupt() {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
	}

	// From here down are functions you may call that interact with the simulator.
	// You should not need to modify these functions.

	// Provided: call this function to start your timer
	@Override
	void starttimer(double increment) {
		Simulator.starttimer(this, increment);
	}
	
	// Provided: call this function to stop your timer
	@Override
	void stoptimer() {
		Simulator.stoptimer(this);
	}
	
	// Provided: call this function when you have data ready for layer5
	@Override
	void tolayer5(char[] data) {
		Simulator.tolayer5(this, data);
	}
	
	// Provided: call this function to send a layer3 packet
	@Override
	void tolayer3(Packet packet) {
		Simulator.tolayer3(this, packet);
	}
	
	// Provided: string representation of this object
	public String toString() {
		return "EntityB";
	}

}
