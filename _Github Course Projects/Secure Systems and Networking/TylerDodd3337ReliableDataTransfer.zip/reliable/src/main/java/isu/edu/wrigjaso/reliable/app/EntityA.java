package isu.edu.wrigjaso.reliable.app;

import java.util.List;
import java.util.ArrayList;

public class EntityA extends Entity {

	public ArrayList<Integer> packetNumsACK;
	public ArrayList<Integer> packetNumSent;
	public ArrayList<Integer> packetsNACK;
	public ArrayList<Packet> packetsSent;
	public int currentPacketSeqNum;
	public int currentPacketNum;
	//public double timeSent;
	
	// Initialize anything you need here
	EntityA() {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
		this.packetNumsACK = new ArrayList<Integer>();	//track packets that have been received
		this.packetNumSent = new ArrayList<Integer>();	//track packets that have been sent
		this.packetsNACK = new ArrayList<Integer>();	//tracks any packet numbers that are NACK from B (corrupted)
		this.packetsSent = new ArrayList<Packet>();	//stores the packets sent by EntityA
		this.currentPacketSeqNum = 0;
		this.currentPacketNum = 0;
		//this.timeSent = Simulator.time;
	}

	// Called when layer5 wants to introduce new data into the stream
	@Override
	void output(Message message) {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");

		// TODO add some code
		Packet pkt = new Packet(); //making new packet

		//copying the message characters into the packet payload
		for (int i = 0; i < message.data.length; i++)
			pkt.payload[i] = message.data[i];
		//generating the checksum value for the packet
		byte checkSum = (byte)0x0000;
		for(char c: message.data){
			byte b = (byte)c;	//turning the char into a byte value
			checkSum += ((byte)0xff - b);	//calculating the complement of the char byte by subtracting it from
											//1111 1111 and adding it to the checksum value
		}
		pkt.checksum = checkSum;	//setting the packet checksum value to the calculated checksum value
		for(int i = 0; i < message.data.length; i++){
			System.out.print(message.data[i] + " ");
		}

		//output case where this is the first packet being sent to B
		if(this.packetNumSent.isEmpty() || this.packetNumsACK.isEmpty()){
			this.currentPacketNum = 0;
			pkt.acknum = this.currentPacketNum;
			pkt.seqnum = 0;
			this.currentPacketSeqNum = 0;
			this.packetNumSent.add(this.currentPacketNum);
			this.packetsSent.add(pkt);
			this.currentPacketNum++;
		}
		//Handling cases where the 
		//output case where this is not the first packet being sent to B and is not a repeat packet
		else if(this.packetNumsACK.get(-1) == (this.currentPacketNum - 1)){	//the previous packet was sent and ACKd
			pkt.acknum = this.currentPacketNum;
			pkt.seqnum = 0;	
			this.currentPacketSeqNum = 0;
			this.packetNumSent.add(pkt.acknum);
			this.packetsSent.add(pkt);
			this.currentPacketNum++;
		}
		//output cases where this is a repeat packet (can be caused by corruption OR packet loss) does not add 
			//new acknum into packetNumSent or increment currentPacketNum
		else if(this.packetNumsACK.get(-1) != (this.currentPacketNum - 1)){
			this.currentPacketSeqNum++;	//incrementing the sequence number of the packet by 1
			pkt.acknum = this.currentPacketNum;	
			pkt.seqnum = this.currentPacketSeqNum;
			
		}
		System.out.println("Sum: " + pkt.checksum);
		System.out.println("Ack: " + pkt.acknum);
		System.out.println("Seq: " + pkt.seqnum);
		System.out.println("PacketNumSent size: " + this.packetNumSent.size());
		
		starttimer(15);	//starting the timer for sending the packet to track possible packet loss 
		tolayer3(pkt);	//sending the packet to entityB through layer3
		
	}

	// Called when the network has a packet for this entity
	@Override
	void input(Packet packet) {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
		stoptimer();//stopping the timer to signify that the packet sent was not lost
		/*turn the payload chars into a string*/
		String msg = "";
		for(char c: packet.payload){
			msg += c;
		}
		/*determine if the response from Entity B is ACK NACK or something else*/
		if(msg.contains("ACK") && !msg.contains("N"))
		{
			this.packetNumsACK.add(packet.acknum);	//adding the current packetNum to packetNumsACK
			
		}
		/*resend packet if NACK or an unknown response (implies ACK/NACK was corrupted)*/
		else
		{
			this.packetsNACK.add(packet.acknum);	//adding packetNum to packetsNACK
			Message currentPacketMessage = new Message();	//creating a message object to use for resending the current packet
			Packet currentPacket = this.packetsSent.get(-1);	//getting the most recent packet from PacketsSent
			currentPacketMessage.data = currentPacket.payload;	//setting the message data to the payload of the packet to be resent
			output(currentPacketMessage);	//resending the packet by calling output function
		}
	}

	// called when your timer has expired
	@Override
	void timerinterrupt() {
		System.out.println(this.getClass().getName() + ":" +
                new Throwable().getStackTrace()[0].getMethodName() + " called.");
		// TODO add some code
		/* resending the packet that was just sent since the packet is assumed to be lost*/
		Message currentPacketMessage = new Message();	//creating a message object to use for resending the current packet
		Packet currentPacket = this.packetsSent.get(-1);	//getting the most recent packet from PacketsSent
		currentPacketMessage.data = currentPacket.payload;	//setting the message data to the payload of the packet to be resent
		output(currentPacketMessage);	//resending the packet by calling output function
	}

	// From here down are functions you may call that interact with the simulator.
	// You should not need to modify these functions.

	// Provided: call this function to start your timer
	@Override
	void starttimer(double increment) {
		Simulator.starttimer(this, increment);
	}
	
	// Provided: call this function to stop your timer
	@Override
	void stoptimer() {
		Simulator.stoptimer(this);
	}
	
	// Provided: call this function when you have data ready for layer5
	@Override
	void tolayer5(char[] data) {
		Simulator.tolayer5(this, data);
	}
	
	// Provided: call this function to send a layer3 packet
	@Override
	void tolayer3(Packet packet) {
		Simulator.tolayer3(this, packet);
	}

	// Provided: string representation of this object
	public String toString() {
		return "EntityA";
	}
}
