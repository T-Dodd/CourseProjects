package edu.isu.wrigjaso.distancevector.app;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        // try{NetworkSimulator simulation = new NetworkSimulator(false, 2, 0);}
        // catch(Exception e){}
        assertTrue( true );
    }
}
