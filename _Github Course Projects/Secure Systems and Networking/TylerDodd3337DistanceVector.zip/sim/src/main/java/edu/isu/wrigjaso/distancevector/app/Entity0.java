package edu.isu.wrigjaso.distancevector.app;

public class Entity0 extends Entity
{    
    // Perform any necessary initialization in the constructor
    public Entity0(int[] startingvector)
    {
    	// startingvector is an array of costs for this Entity.
    	// startingvector[0] will be 0 (zero cost to talk to yourself)
    	// if startingvector[n] == 999, then node 'n' is not actually connected
    	// to this node.

        for(int i = 0; i < this.distanceTable.length; i++){ //default all table values to infinity
            for(int j = 0; j < this.distanceTable.length; j++){
                this.distanceTable[i][j] = 999;
            }
        }

        this.distanceTable[0] = startingvector; //sets row 0 to the starting vector for 0
        
        for(int i = 0; i < startingvector.length; i++){ //setting col 0 to the starting vector for 0
            this.distanceTable[i][0] = startingvector[i];
        }
        
        boolean test = true;    //used solely for breakpoint to observe DVT updates properly from debug menu
    }
 
    // Called when the simulator is ready to start handling packets.
    // This should be the first function that sends this Entity's vector to
    // its neighbors by calling NetworkSimulator.toLayer2()
    public void start() 
    {
        //send to nodes with values that are not 0(self) or 999(no connection)
        for(int i = 0; i < this.distanceTable[3].length; i++)
        {
            if(this.distanceTable[0][i] != 0 && this.distanceTable[0][i] != 999)
            {
                Packet packet = new Packet(0, i, this.distanceTable[0]);
                NetworkSimulator.toLayer2(packet);
            }
        }
    }

    // Handle updates when a packet is received.  Students will need to call
    // NetworkSimulator.toLayer2() with new packets based upon what they
    // send to update.  Be careful to construct the source and destination of
    // the packet correctly.  Read the warning in NetworkSimulator.java for more
    // details.
    public void update(Packet p)
    {
        int source = p.getSource(); //get the source entity 
        int dest = p.getDest();
        boolean needsUpdate = false;    //flag to notify if updated distance table needs to be sent out

        //check to make sure that there is a connection between this entity and the source entity
        if(NetworkSimulator.cost[dest][source] != 999)
        {
            //create an array containing the minCosts sent by the source entity
            int[] minCosts = new int[this.distanceTable[source].length];
            for(int i =0; i < this.distanceTable[source].length; i++)
            {
                minCosts[i] = p.getMincost(i);
            }
            //iterate through the minCosts list and compare with the minCosts in the current distanceTable
            //runs through the list on each row and column for the source AND destination entities
            //running through destination
            for(int i = 0; i<minCosts.length;i++)
            {
                //is the min cost from a->c less than b->c
                if(this.distanceTable[dest][i] > minCosts[i])
                {
                    //is the minCost unkown to this entity (999)
                    if(this.distanceTable[dest][i] == 999){
                        this.distanceTable[dest][i] = minCosts[i];
                        this.distanceTable[i][dest] = minCosts[i];
                    }
                    //is the min cost from a->b + b->c less than a->c
                    int cost = this.distanceTable[dest][i] + minCosts[i];
                    if(this.distanceTable[dest][i] > cost)
                    {
                        //swapping both row,col and col,row positions since the links are bidirectional
                        this.distanceTable[dest][i] = cost;
                        this.distanceTable[i][dest] = cost;
                        needsUpdate = true;
                    }
                }
            }
            //running through source
            for(int i = 0; i < minCosts.length; i++)
            {
                //is the min cost from a->c less than b->c
                if(this.distanceTable[source][i] > minCosts[i])
                {
                    //is the minCost unkown to this entity (999)
                    if(this.distanceTable[source][i] == 999){
                        this.distanceTable[source][i] = minCosts[i];
                        this.distanceTable[i][source] = minCosts[i];
                    }
                    //is the min cost from a->b + b->c less than a->c
                    int cost = this.distanceTable[source][i] + minCosts[i];
                    if(this.distanceTable[source][i] > cost)
                    {
                        this.distanceTable[source][i] = cost;
                        this.distanceTable[i][source] = cost;
                        needsUpdate = true;
                    }
                }
            }          
        }
        //runs if there is a distance table value that has been updated and needs to be broadcast
        if(needsUpdate)
        {
            //generate the new mincosts for the source entity
            int[] minCosts = new int[this.distanceTable[source].length];
            for(int i = 0; i < minCosts.length; i++)
            {
                minCosts[i] = this.distanceTable[source][i];
            }
            //send out the updated list of mincosts to connected entities
            for(int i = 0; i < minCosts.length; i++){
                if(this.distanceTable[source][i] != 999)
                {
                    Packet packet = new Packet(source, i, minCosts);
                    NetworkSimulator.toLayer2(packet);
                }
            }
        }    
    }

    // for extra credit, handle the case where the cost of a link changes.
    public void linkCostChangeHandler(int whichLink, int newCost)
    {
    }
    
    public void printDT()
    {
        System.out.println();
        System.out.println("           via");
        System.out.println(" D0 |   1   2   3");
        System.out.println("----+------------");
        for (int i = 1; i < NetworkSimulator.NUMENTITIES; i++)
        {
            System.out.print("   " + i + "|");
            for (int j = 1; j < NetworkSimulator.NUMENTITIES; j++)
            {
                if (distanceTable[i][j] < 10)
                {    
                    System.out.print("   ");
                }
                else if (distanceTable[i][j] < 100)
                {
                    System.out.print("  ");
                }
                else 
                {
                    System.out.print(" ");
                }
                
                System.out.print(distanceTable[i][j]);
            }
            System.out.println();
        }
    }
}
