import java.net.*;
import java.time.*;
import java.io.*;
import java.util.*;



public class UDPInger {

    
    /*global variables*/
    static DatagramSocket serverPing;
    public static String logText = "";
    public static void main(String[] args)
    {
        
        InetAddress serverAddress;
        int serverPort = 8192;
        int numberOfPings = 10;
        
        try{
            serverAddress = InetAddress.getByName("simplesmtp.thought.net");
            
            //opening a new socket
            serverPing = new DatagramSocket();
            
            int packetsLost = 0;
            int[] packetSendTimes = new int[numberOfPings];
            int sentPacketCount = 0;
            long[] timeDelays = new long[numberOfPings];
            
            //a for loop that pings the server numberOfPings times
            for(int pingIndex = 0; pingIndex < numberOfPings; pingIndex++)
            {
                boolean packetReceived = false;
                String message = "packet number " + pingIndex;
                DatagramPacket sendingPacket = new DatagramPacket(message.getBytes(), 0, message.length(), serverAddress, serverPort);
                sendPing(sendingPacket);
                long timeSent = Calendar.getInstance().getTimeInMillis();
                long timeTaken = Calendar.getInstance().getTimeInMillis() - timeSent;
                
                byte[] receivedBuffer = new byte[1024];
                while(!packetReceived){
                    DatagramPacket serverResponse = new DatagramPacket(receivedBuffer, receivedBuffer.length); 
                    timeTaken = Calendar.getInstance().getTimeInMillis() - timeSent;
                    
                    //no response from server after 1 sec
                    if(timeTaken > 1000 && serverResponse.getLength() == 0){
                        packetsLost++;
                        // timeDelays[pingIndex] = timeTaken;
                        System.out.println("Packet number " + pingIndex + " has been lost");
                        logText += "Packet number " + pingIndex + " has been lost\r\n";
                        packetReceived = true;
                    }
                    else if(timeTaken < 1000 && serverResponse.getLength() > 0){
                        timeDelays[pingIndex] = timeTaken;
                        System.out.println("Received: packet number " + pingIndex + " | Delay: " + timeTaken + " ms");
                        // String pack = new String(serverResponse.getData());
                        // System.out.println("Server response message : " + pack);
                        logText += "Received: packet number " + pingIndex + " | Delay: " + timeTaken + " ms\r\n";
                        packetReceived = true;
                    }
                    else{
                        System.out.println("An error occurred");
                    }
                }
                
            }

            float averageDelay = avgDelay(timeDelays);
            long minDelay = getMin(timeDelays);
            long maxDelay = getMax(timeDelays);

            logText += "Minimum Delay: " + minDelay + "ms \r\n";
            logText += "Maximum Delay: " + maxDelay + "ms \r\n";
            logText += "Average Delay: " + averageDelay + "ms\r\n";

            System.out.println("-----------------------------------------------------------");
            System.out.print(logText);

            FileWriter logFile = new FileWriter("UDPLogFile.txt");
            logFile.write(logText);
            logFile.close();
        }
        catch(Exception e){
            System.out.println(e.getStackTrace());
        }
       

    }

    /*Sends a message to the socket passed as a parameter. Tracks the time between message sending and confirmation response*/
    public static void sendPing(DatagramPacket packet)
    {
        try{
            String message = new String(packet.getData());
            System.out.println("Attempting to send " + message);
            logText += "Attempting to send " + message + "\r\n";
            serverPing.send(packet);
        }
        catch(Exception e){
            System.out.println(e.getStackTrace());
        }
    }


    public static float avgDelay(long[] delays){
        long sum = 0;
        for(long d:delays){
            sum += d;
        }
        float average = Float.parseFloat(Long.toString(sum))/delays.length;
        return average;
    }

    public static long getMin(long[] delays){
        long min = 0;
        for(long d:delays){
            if(min > d){
                min = d;
            }
        }
        return min;
    }

    public static long getMax(long[] delays){
        long max = 0;
        for(long d:delays){
            if(max < d){
                max = d;
            }
        }
        return max;
    }
}

