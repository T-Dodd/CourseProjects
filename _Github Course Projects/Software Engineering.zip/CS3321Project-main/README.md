# CS3321 Project, Spring 2023

# Contributors
* Tyson Cox
* Tyler Dodd
* Conley O'Neill

# Diagram Link
* https://lucid.app/lucidchart/95aa1562-7565-4c8e-8f0f-223d1d04cd02/edit?viewport_loc=-2832%2C-1059%2C5713%2C2853%2C0_0&invitationId=inv_8cfd560c-bdea-43a5-bf61-ac877f1aa4d9

# SBOM
* java 17
* MariaDB 10.11
* javafx 19
* Gradle 7.3.3
* JUnit-jupiter 5.7.2
* guava 30.1.1-jre
* json-simple 1.1.1
* pdfbox 2.0.27
