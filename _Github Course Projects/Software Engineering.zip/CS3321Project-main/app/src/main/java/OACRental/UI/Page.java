package OACRental.UI;

public interface Page {
    void update();
}
